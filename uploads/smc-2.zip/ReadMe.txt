.
.
.
INCOMING SUB-ETHA FACSIMILE...
.
FROM: Intergalactic Computers, Inc.
.
DATE: IGSD 178.2263.4
.
AUTHENTICATION CONFIRMED
.
DECRYPTING..................
COMPLETE.
.
DOCUMENT PROCEEDS:


   Greetings Trader,

   Congratulations on your succesfull acquisition of our fine 
   Space Merchant Companion (SMC) computer add-on for you vessel.
   Just connect the SMC Module to your navigational computer on 
   your vessel using any of the available SLC connections.  The
   SMC module will automatically identify your vessel type and 
   adjust itself accordingly.

   Notice:
   SMC is still under development.  Parts of it are not yet 
   operational.  Here's what's finished and usefull so far:

   General functions
   -----------------
   * Weapon List
     The same weaponlist you can access through your normal Space 
	 Merchant control panel (common referred to as a Web-browser)
	 can also be accessed via the SMC module.
	 Press the Weapon List button, Ctrl+W or select References, 
	 Weapon List from the menu.
	 The weaponlist itself is sizable, and size is stored.
	 You can sort by any column by clicking it's header.
   * Ship List
     Identical to the Weapon List, a complete list of ships is also
	 available from the SMC module.
	 Press the Ship List button, Ctrl+S or select References, Ship 
	 List from the menu.

   Game specific functions
   -----------------------
   * Universe creation is operational.  So is selecting a game, 
     selecting a galaxy within a game and jumping to a sector.
   * The galactic map and custom viewing is operational.
   * Manual sector editing is operational.
   * Intergalactic course plotting is operational.
   * Sectorinfo
     You can obtain info about the distance of any particular sector
	 to any other location, or item.
   * Find Traderoute
     Search any galaxy for potential traderoutes.  SMC will give you the
	 potential routes ranked by either max experience gain, or max profit.
	 You can obtain a list of 2, 3 and 4 port routes.
	 It is possible to disable certain goods or races from the routefinder.

   * Optimal Trip calculation (temporal implementation)
     If you need to visit several sectors on a regular basis
	 (restocking/building planets) you can use this feature. 
	 to minimize the number of turns required to visit all 
	 locations.
	 You select the sectors to be visited in the list (Ctrl+Click on 
	 the sectors you want).
	 It'll determine a round trip: returning to the sector of origin.
	 Up to about 12 sectors will give you a near instant result.
	 13 sectors will take a second or so
	 14 sectors will take a couple seconds
	 15 sectors takes 2min15 on my PII 300Mhz.
	 16 will be something like 30min or more (haven't tried that)
	 The reason it's so slow is because there are exponentially 
	 more possible combinations to be tested for each extra sector.
	 For those interested in some math.
     With n sector, there are (n-1)! possible combinations.
	 If you want to find the optimum route between 16 sectors,
	 that means 15! (1.307.674.368.000) possible combinations to be 
	 tested.  Good thing there are a few tricks you can pull to limit
	 the amount of combinations you actually have to test.
	 I'm working on getting this speeded up.
	 
	 In the finished program you'll just enter the sectors you want, 
	 it'll autocalculate each distance. And calculate an optimum trip.
	 there won't be a distance to locations table like there is now.

   Notes
   -----
   * If you download the KotH database as well, you're all set to go.
	 
     Any comments appreciated...  
     E-mail them to:     Tasmaniac@online.be
     SMC:                users.skynet.be/ThePlaceToBe (case sensitive)


...TRANSMISSION ENDS
.
...TERMINATING CONNECTION
.


